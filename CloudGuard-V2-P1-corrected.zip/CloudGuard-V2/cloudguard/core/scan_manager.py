from datetime import datetime, timezone
from time import perf_counter

from cloudguard.core.rules import attach_rule_metadata
from cloudguard.scanners.s3_scanner import S3Scanner
from cloudguard.scanners.iam_scanner import IAMScanner
from cloudguard.scanners.ec2_scanner import EC2Scanner
from cloudguard.scanners.ebs_scanner import EBSScanner
from cloudguard.scanners.rds_scanner import RDSScanner
from cloudguard.scanners.cloudtrail_scanner import CloudTrailScanner


class ScanManager:
    """Run all six read-only scanners and retain independent module timings."""

    def __init__(self):
        self.scanners = [
            ("S3", S3Scanner),
            ("IAM", IAMScanner),
            ("EC2", EC2Scanner),
            ("EBS", EBSScanner),
            ("RDS", RDSScanner),
            ("CloudTrail", CloudTrailScanner),
        ]

    def run_all(self):
        started_at = datetime.now(timezone.utc)
        wall_start = perf_counter()
        service_results, all_findings, all_errors = {}, [], []
        completed_scanners = 0

        for service_name, scanner_class in self.scanners:
            print(f"[CloudGuard] Scanning {service_name}...")
            module_start = perf_counter()
            try:
                result = scanner_class().scan() or {}
                completed_scanners += 1
                result.setdefault("service", service_name)
                findings = result.get("findings", []) or []
                errors = result.get("errors", []) or []
                for finding in findings:
                    attach_rule_metadata(finding)
                all_findings.extend(findings)
                for error in errors:
                    if isinstance(error, dict):
                        all_errors.append({"service": service_name, **error})
                    else:
                        all_errors.append({"service": service_name, "message": str(error)})
                result["duration_seconds"] = round(perf_counter() - module_start, 4)
                service_results[service_name] = result
                print(f"[CloudGuard] {service_name}: {len(findings)} finding(s), "
                      f"{len(errors)} error(s), {result['duration_seconds']} s")
            except Exception as error:
                duration = round(perf_counter() - module_start, 4)
                error_result = {
                    "service": service_name,
                    "operation": "scanner_execution",
                    "message": str(error),
                }
                all_errors.append(error_result)
                service_results[service_name] = {
                    "service": service_name, "findings": [],
                    "errors": [error_result], "duration_seconds": duration,
                }
                print(f"[CloudGuard] {service_name} failed after {duration} s: {error}")

        completed_at = datetime.now(timezone.utc)
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for finding in all_findings:
            severity = str(finding.get("severity", "INFO")).upper()
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        return {
            "tool": "CloudGuard",
            "scan_started_at": started_at.isoformat(),
            "scan_completed_at": completed_at.isoformat(),
            "duration_seconds": round(perf_counter() - wall_start, 4),
            "summary": {
                "total_scanners": len(self.scanners),
                "completed_scanners": completed_scanners,
                "total_findings": len(all_findings),
                "total_errors": len(all_errors),
                "severity_counts": severity_counts,
            },
            "services": service_results,
            "findings": all_findings,
            "errors": all_errors,
        }
